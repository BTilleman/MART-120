let circleY = 100; 
let triangleY = 75; 
let rectX1 = 65; 
let rectX2 = 90; 
let lastUpdateTime = 0;
let circleDir = 1; 
let triangleDir = -1; 
let rectDir1 = 1; 
let rectDir2 = -1; 
let textSizeFactor = 1; 

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  
  if (millis() - lastUpdateTime >= 300) {
    lastUpdateTime = millis();
    
   
    circleY += circleDir * 6; // move the circle by 6 pixels vertically
    if (circleY >= 45 || circleY <= 35) {
      circleDir *= -1;
    }
    
   
    triangleY += triangleDir * 5;
    if (triangleY >= 20 || triangleY <= 10) {
      triangleDir *= -1;
    }
    
    
    rectX1 += rectDir1 * 3;
    if (rectX1 >= 70 || rectX1 <= 60) {
      rectDir1 *= -1;
    }
    
   
    rectX2 += rectDir2 * 3;
    if (rectX2 >= 95 || rectX2 <= 85) {
      rectDir2 *= -1;
    }
    
   
    textSizeFactor = 1 + sin(millis() * 0.005) * 0.5; // adjust the 0.005 value to control the speed
  }
  
 
  circle(90, circleY, 70);
  rect(rectX1, 135, 50, 90);
  point(70, 90);
  point(90, 90);
  line(90, 100, 120, 200);
  line(50, 100, 65, 200);
  triangle(65, triangleY, 87.5, triangleY - 45, 110, triangleY);
  rect(rectX2, 200, 25, 90);
  rect(rectX1, 200, 25, 90);
  
  textSize(32 * textSizeFactor); // apply the text size factor
  text('Big Day Party', 100, 30);
  textSize(12);
  text('Bri', 20, 380);
}
