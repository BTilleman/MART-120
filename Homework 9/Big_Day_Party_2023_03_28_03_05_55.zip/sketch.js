function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
   circle(90,100,70);
  rect(65,135,50,90);
   point(70,90)
  point(90,90)
  line(90,100,120,200);
  line(50,100,65,200);
   triangle(65, 75, 87.5, 20, 110, 75);
  rect(65,200,25,90);
  rect(90,200,25,90);
      textSize(32);
  text('Big Day Party', 100, 30);
  textSize(12);
    text('Bri', 20, 380);
}